package com.example.chordproapp

data class Song(
    val title: String,
    val artist: String,
    val content: String,
    // Any other attributes
)