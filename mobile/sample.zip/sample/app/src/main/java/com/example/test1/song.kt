package com.example.test1

data class Song(
    val title: String,
    val artist: String,
    val content: String,
    // Any other attributes
)